package com.qa.autopractise.factory;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.qa.autopractise.utils.Constants;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Driver_Factory {
	WebDriver driver;
	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();//threadlocal concept

	public WebDriver init_driver(String browsername) {

		System.out.println("The browser name is :" + Constants.BROWSERNAME);

		if (browsername.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else if (browsername.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} else {
			System.out.println("Please pass the correct browser :" + browsername);
		}
         
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get(Constants.URL);
		return driver;
	}
	public static synchronized WebDriver getDriver() {
		return 	tlDriver.get();
		}
	public String getScreenshot() {
		File src = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		String path = System.getProperty("user.dir")+"/screenshots/"+System.currentTimeMillis()+".png";
		File destination = new File(path);
		try {
			FileUtils.copyFile(src, destination);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return path;
	}
}