package com.qa.autopractise.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.autopractise.utils.Constants;
import com.qa.autopractise.utils.ElementUtil;

public class LoginPage {

	private WebDriver driver;
	private ElementUtil elementUtil;

	private By signin = By.xpath("//a[@class='login']");
	private By email = By.id("email");
	private By password = By.id("passwd");
	private By login =By.id("SubmitLogin");
	private By home=By.xpath("//a[@title='Home']");

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		elementUtil = new ElementUtil(driver);
	}

	public String getPageTitle() {
		return elementUtil.waitForTitle(10, Constants.PAGE_TITLE);
	}

	public String doLogin(String un, String pwd) {
		elementUtil.doClick(signin);
		elementUtil.WaitFor(10);
		elementUtil.doClick(email);
		elementUtil.doSendKeys(email, un);
		elementUtil.doClick(password);
		elementUtil.doSendKeys(password, pwd);
		elementUtil.doClick(login);
	  return elementUtil.waitForTitle(10, Constants.LOGIN_PAGE_TITLE);
	}
      public ShoppingPage gotohomepage() {
    	  elementUtil.doClick(home); 
    	  return new ShoppingPage(driver);
      }

	
}
