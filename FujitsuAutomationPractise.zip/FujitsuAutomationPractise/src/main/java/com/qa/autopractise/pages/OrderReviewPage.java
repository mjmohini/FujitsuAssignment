package com.qa.autopractise.pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.qa.autopractise.utils.Constants;
import com.qa.autopractise.utils.ElementUtil;

public class OrderReviewPage {

	private WebDriver driver;
	private ElementUtil elementUtil;

	private By orderhistorybutton = By.xpath("//a[@title='Orders']");
	private By date = By.xpath("(//td[@class='history_date bold'])[1]");
	private By order = By.xpath("(//a[@class='color-myaccount'])[1]");
	private By selectprod = By.xpath("//select[@name='id_product']");
	private By textarea = By.xpath("//textarea[@name='msgText']");
	private By send = By.xpath("(//button[@type='submit'])[2]");
	private By messagetext = By.xpath("(//tr[@class='first_item item']/td)[4]");
	private By logout = By.xpath("//a[@class='logout']");
	private By text = By.xpath("((//tr[@class='item'])[4]/td/label)[2]");

	public OrderReviewPage(WebDriver driver) {
		this.driver = driver;
		elementUtil = new ElementUtil(driver);

	}

	public String review() {
		elementUtil.doClick(orderhistorybutton);
		String dateofitem = elementUtil.getElement(date).getText();
		elementUtil.doClick(order);
		elementUtil.doSelectDropDownValueByValue(selectprod, "2");
		elementUtil.doSendKeys(textarea, Constants.MESSAGE);
		elementUtil.doClick(send);
		String message = elementUtil.getElement(messagetext).getText();
		return message;
	}

	public void logout() {
		elementUtil.doClick(logout);
	}

	public String screengrab() {
		elementUtil.doClick(orderhistorybutton);
		elementUtil.doClick(order);
		String prodname = elementUtil.getElement(text).getText();
		return prodname;
	}

	public void takeScreenshot() throws Exception {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(new File("E:\\Mohini\\Failed.png"), src);
		
		
		/*
		 * File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		 * String path =
		 * System.getProperty("C:\\Users\\admin\\Documents\\screenshot")+"/screenshots/"
		 * +System.currentTimeMillis()+".png"; File destination = new File(path);
		 * 
		 * try { FileUtils.copyFile(src, destination); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */
	}

}
