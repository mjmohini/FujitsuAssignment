package com.qa.autopractise.utils;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ElementUtil {

	private WebDriver driver;

	public ElementUtil(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getElement(By locator) {
		WebElement ele = driver.findElement(locator);
		return ele;
	}

	public void doClick(By locator) {
		try {
			driver.findElement(locator).click();
		}catch(Exception e) {
			try {
				System.out.println("Start Java Click");
				WaitFor(10);
				clickElementByJS(driver.findElement(locator));
			}catch(Exception ae) {
				WaitFor(10);
				doActionclick(locator);
			}
		}
		
	}

	public String waitForTitle(int timeout, String Title) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.titleIs(Title));
		return driver.getTitle();
	}

	public void waitForElementload(By path, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(path)));
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(path)));
	}
	public void doActionclick(By locator) {
		Actions act=new Actions(driver);
		act.moveToElement(driver.findElement(locator)).click().perform();
	}

	public void WaitFor(int sec) {
		driver.manage().timeouts().implicitlyWait(sec, TimeUnit.SECONDS);
	}

	public void waitForCYSLogo() {
		By pageLoad = By.xpath("//img[@alt='loading']");
		int Size = 1, count = 0;
		waitForElementload(pageLoad, 20);
		while (Size > 0) {
			Size = driver.findElements(pageLoad).size();
			count++;
			WaitFor(5);
			if (count > 10000) {
				break;
			}
		}
	}
	public void doActionsMoveToElement(By locator) {
		Actions act = new Actions(driver);
		act.moveToElement(getElement(locator)).perform();
	}
//	public void doActionsMoveToElementAndClick(By locator) {
//		doActionsMoveToElement(locator);
//		getElement(locator).click();
//	}
	public void doSendKeys(By locator, String value) {

		WebElement element = getElement(locator);
		element.clear();
		element.sendKeys(value);
	}

	public void clickElementByJS(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element);
	}

	public void waitForElement(By locator) {
		By pageLoad = locator;
		int Size = 1, count = 0;
		waitForElementload(pageLoad, 30);
		while (Size > 0) {
			Size = driver.findElements(pageLoad).size();
			count++;
			WaitFor(5);
			if (count > 10000) {
				break;
			}
		}
	}
	
	
	public void doSelectDropDownValueByVisibleText(By Locator, String text) {
		Select sel = new Select(driver.findElement(Locator));
		sel.selectByVisibleText(text);
	}
	public void doSelectDropDownValueByValue(By Locator, String value) {
		Select sel = new Select(driver.findElement(Locator));
		sel.selectByValue(value);
	}
	public WebDriver waitForFrameWithFluentWait(String Framelocator, int timeout, long pollingtime) {

		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(timeout))
				.pollingEvery(Duration.ofSeconds(pollingtime)).ignoring(NoSuchFrameException.class);
		return wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(Framelocator));
	}
	public void waitForFrameAndSwitchToIt(WebElement frameElement, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameElement));
	}
	public void scrollPageDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}
	
}
