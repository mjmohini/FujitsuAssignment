package com.qa.autopractise.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.qa.autopractise.utils.ElementUtil;

public class ShoppingPage {

	private WebDriver driver;
	private ElementUtil elementUtil;

	private By item1 = By.xpath("(//img[@alt='Faded Short Sleeve T-shirts'])[1]");
	private By sizedopdown = By.xpath("//div[@id='uniform-group_1']/select");
	private By iframe =By.xpath("//iframe[contains(@id,'fancybox')]");
//	private By sizeL=By.xpath("//select[@id='group_1']/option[@title='L']");
//	private By clickdropdown = By.xpath("//select[@id='group_1']");
	private By addtocart = By.xpath("//button[@name='Submit']");
	private By continueshopping = By.xpath("//span[@title='Continue shopping']");
	private By item2 = By.xpath("(//img[@title='Blouse'])[1]");
	private By checkout = By.xpath("//a[@title='Proceed to checkout']");
	private By firstprice = By.id("product_price_1_3_514184");
	private By secondprice = By.id("product_price_2_7_514184");
	private By shippingcharges = By.id("total_shipping");
	private By totalcharge = By.id("total_price_without_tax");
	private By proceedToCheckout=By.xpath("(//a[@title='Proceed to checkout'])[2]");
	private By againproceedtocheckout=By.xpath("//button[@name='processAddress']");
	private By checkbox=By.xpath("//input[@type='checkbox']");
	private By againproccedtocheckoutfromshipping=By.xpath("//button[@name='processCarrier']");
	private By paybybankwire=By.xpath("//a[@title='Pay by bank wire']");
	private By confirmorder=By.xpath("(//button[@type='submit'])[2]");
	private By logout=By.xpath("//a[@class='logout']");
  
	public ShoppingPage(WebDriver driver) {
		this.driver = driver;
		elementUtil = new ElementUtil(driver);

	}

	public void selectFirstItem() {
		elementUtil.doClick(item1);
		elementUtil.WaitFor(10);
//		elementUtil.doClick(clickdropdown);
//		elementUtil.doClick(sizeL);
//		elementUtil.waitForFrameWithFluentWait(frame, 10, 2);
		elementUtil.waitForFrameAndSwitchToIt(driver.findElement(iframe), 30);
		elementUtil.doSelectDropDownValueByValue(sizedopdown, "2");
		elementUtil.doClick(addtocart);
		elementUtil.doClick(continueshopping);
	}

	public void selectSecondItem() {
		elementUtil.doClick(item2);
		elementUtil.waitForFrameAndSwitchToIt(driver.findElement(iframe), 30);
		elementUtil.doClick(addtocart);
		elementUtil.doClick(checkout);
	}

	public float shoppingCartSummary() {
		String priceee1 = elementUtil.getElement(firstprice).getText();
		String price1=priceee1.substring(1);
		String priceee2 = elementUtil.getElement(secondprice).getText();
		String price2=priceee2.substring(1);
		String shippingggg = elementUtil.getElement(shippingcharges).getText();
		String shipping=shippingggg.substring(1);
		float value1 = Float.parseFloat(price1);
		float value2 = Float.parseFloat(price2);
		float shipcharge = Float.parseFloat(shipping);
		float addition = value1 + value2 + shipcharge;
		return addition;
	}
	public float totalpricevalidation() {
		String totalp = elementUtil.getElement(totalcharge).getText();
		String totalprice=totalp.substring(1);
		float totalcharge = Float.parseFloat(totalprice);
		return totalcharge;
	}
	public OrderReviewPage proceedToCheckoutandlogout() {
		//elementUtil.WaitFor(30);
		elementUtil.scrollPageDown();
		elementUtil.doClick(proceedToCheckout);
		elementUtil.doClick(againproceedtocheckout);
		elementUtil.doClick(checkbox);
		elementUtil.doClick(againproccedtocheckoutfromshipping);
		elementUtil.doClick(paybybankwire);
		elementUtil.doClick(confirmorder);
		elementUtil.doClick(logout);
		return new OrderReviewPage(driver);
	}

}
