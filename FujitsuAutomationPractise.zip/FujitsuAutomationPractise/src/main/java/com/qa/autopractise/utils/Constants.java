package com.qa.autopractise.utils;

public class Constants {
	
public static final String PAGE_TITLE = "My Store";
	
	public static final String URL = "http://automationpractice.com/";
	
	public static final String USERNAME="mohini789@yahoo.com";
	
	public static final String PASSWORD="Syntel*123#";

	public static final String BROWSERNAME="chrome";

	public static final String LOGIN_PAGE_TITLE = "My account - My Store";
	
	public static final String MESSAGE = "I have added comment";


	

}
