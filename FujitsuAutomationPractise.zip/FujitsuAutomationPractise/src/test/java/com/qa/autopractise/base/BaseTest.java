package com.qa.autopractise.base;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.qa.autopractise.factory.Driver_Factory;
import com.qa.autopractise.pages.LoginPage;
import com.qa.autopractise.pages.OrderReviewPage;
import com.qa.autopractise.pages.ShoppingPage;
import com.qa.autopractise.utils.Constants;

public class BaseTest {

	
	Driver_Factory df;
	public WebDriver driver;
	public LoginPage loginpage;
	public ShoppingPage shoppingpage ;
	public OrderReviewPage orderreviewpage;
	
	@BeforeTest
	public void setUp() {
		df = new Driver_Factory();
		driver = df.init_driver(Constants.BROWSERNAME);
		loginpage = new LoginPage(driver);
		shoppingpage=new ShoppingPage(driver);
		orderreviewpage=new OrderReviewPage(driver);
	
	}

	@AfterTest
	public void tearDown() {
	//	driver.quit();
	}
}
