package com.qa.autopractise.test;

import io.restassured.response.Response;
import static io.restassured.RestAssured.*;

import org.junit.Assert;
import org.testng.annotations.Test;

public class Read_API_Test {
	@Test
	public void getdetails() {
		Response response = 
				given()
				.when()
				.get("https://reqres.in/api/users/2")
				.then()
				.statusCode(200)
				.statusLine("HTTP/1.1 200 OK").assertThat().statusCode(200).log().all().extract().response();

		String resp = response.asString();
		Assert.assertEquals(resp.contains("contributions towards server"), true);
	}
}
