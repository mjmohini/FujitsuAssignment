package com.qa.autopractise.test;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Delete_API_Test {
	@Test
	public void DeleteRecord()
	{
		RestAssured.baseURI="https://reqres.in/api";
		
		RestAssured.basePath="/users/2";
		
		given()

		.when()
		.delete()
		
		.then()
		.statusCode(204)
		.statusLine("HTTP/1.1 204 No Content")
		.log().all();
	
		
	}

}
