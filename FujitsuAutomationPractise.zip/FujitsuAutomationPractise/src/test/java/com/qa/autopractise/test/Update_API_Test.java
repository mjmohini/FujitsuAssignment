package com.qa.autopractise.test;

import static io.restassured.RestAssured.given;

import java.util.HashMap;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Update_API_Test {

public static HashMap map=new HashMap();
	
	@BeforeTest
	
	public void Beforeput() 
	
	{
		map.put("first_name", "Mohini");
		map.put("id", "2");
		map.put("last_name", "Jadhav");
		
		RestAssured.baseURI="https://reqres.in/api";
		RestAssured.basePath="/users/2";
		
		
	}
	@Test
	public void put() {
		
		given()
		.contentType("Application/json")
		.body(map)
		.when()
		.put()
		.then()
		.statusCode(200)
		.log().all();
		
		
	}

}

