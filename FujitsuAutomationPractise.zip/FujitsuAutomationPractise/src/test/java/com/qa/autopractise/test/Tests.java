package com.qa.autopractise.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.autopractise.base.BaseTest;
import com.qa.autopractise.utils.Constants;

public class Tests extends BaseTest {

	@Test(priority = 1)

	public void TitleTest() throws Exception {
		String title = loginpage.getPageTitle();
		orderreviewpage.takeScreenshot();
		System.out.println("Page title is :" + title);
		Assert.assertEquals(title, Constants.PAGE_TITLE);
	}

	@Test(priority = 2)
	public void loginTest() {
		String title2 = loginpage.doLogin(Constants.USERNAME, Constants.PASSWORD);
		System.out.println("Login Page title is :" + title2);
		Assert.assertEquals(title2, Constants.LOGIN_PAGE_TITLE);
		System.out.println("User logged in successfuly");
	}
	@Test(priority=3)
	
	
	public void goToHomePageTest() {
		loginpage.gotohomepage();
	}
	
	@Test(priority=4)
	
	public void SelectFirstItemTest() {
		shoppingpage.selectFirstItem();
		System.out.println("Fisrt item added to the cart");
	}
	@Test(priority=5)
	public void SelectSecondItemTest() {
		shoppingpage.selectSecondItem();
		System.out.println("Second item added to the cart");
	}
	@Test(priority=6)
	public void verifyTotalCharges() {
	float addition=	shoppingpage.shoppingCartSummary();
	System.out.println(addition);
	float total= shoppingpage.totalpricevalidation();
	System.out.println(total);
	final double THRESHOLD = .000005;
	if (Math.abs(addition - total) < THRESHOLD)
        System.out.println("Addition and Total prices are equal using threshold\n");
    else
        System.out.println("Addition and Total prices are not equal using threshold\n");
	
	}
	@Test(priority=7)
	public void checkoutAndLogoutTest() {
		shoppingpage.proceedToCheckoutandlogout();
		System.out.println("Order completed successfuly");
	}
	@Test(priority=8)
	public void loginAndReview() {
		String title2 = loginpage.doLogin(Constants.USERNAME, Constants.PASSWORD);
		System.out.println("Login Page title is :" + title2);
		Assert.assertEquals(title2, Constants.LOGIN_PAGE_TITLE);
		System.out.println("User logged in successfuly");
		String mymessage=orderreviewpage.review();
		Assert.assertEquals(mymessage, Constants.MESSAGE);
		System.out.println("Message is confirmed");
	}
	@Test(priority=9)
	public void validateColorTest() throws Exception {
		orderreviewpage.logout();
		String title2 = loginpage.doLogin(Constants.USERNAME, Constants.PASSWORD);
		System.out.println("Login Page title is :" + title2);
		Assert.assertEquals(title2, Constants.LOGIN_PAGE_TITLE);
		System.out.println("User logged in successfuly");
		String s1=orderreviewpage.screengrab();
		String s2=s1.trim();
		System.out.println(s2);	
		String Expectedcolor="Faded Short Sleeve T-shirts - Color : Pink, Size : M";
		orderreviewpage.takeScreenshot();
		Assert.assertEquals(s2, Expectedcolor);
		
	}
	
	
}
