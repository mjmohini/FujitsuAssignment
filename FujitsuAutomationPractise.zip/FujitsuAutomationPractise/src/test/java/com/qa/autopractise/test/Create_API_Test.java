package com.qa.autopractise.test;

import static io.restassured.RestAssured.given;

import java.util.HashMap;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Create_API_Test {

	public static HashMap map = new HashMap();

	@BeforeTest

	public void postdata() {

		map.put("id", 9);
		map.put("email", "mohini.lawson@reqres.in");
		map.put("first_name", "mohini");
		map.put("last_name", "jadhav");

		RestAssured.baseURI = "https://reqres.in/api/";
		RestAssured.basePath = "/users";

	}

	@Test

	public void TestPost() {

		given().contentType("application/json").body(map)

				.when().post()

				.then().statusCode(201).and().assertThat();
		// System.out.println("statusCode"+statusCode);
		// .body("id", "613");

	}
}

